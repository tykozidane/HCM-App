<?php

namespace Myth\Auth\Test\Fakers;

use Myth\Auth\Models\UserModel;

class UserFaker extends UserModel
{
}
